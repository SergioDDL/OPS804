
#Advanced Analytics HW# #
#Predict car Price

student_ID <- 00935115

library(leaps)
library(broom)
library(ggplot2)
library(e1071)
library(Rcmdr)
library(pastecs)
library(sqldf)




#Loading the data
Toy <- read.csv("ToyotaCorolla.csv")

#I want to see the top 6 data points of the file
head(Toy)

# This pulls most of discriptive statistics for my data
stat.desc(Toy)

# This gives me the remaining discriptive statistics i feel i need
summary(Toy)

summary(Toy$FuelType)

# we must fix our data in order to conduct the predictive model. The code below converts a categorical variable to 
# a binary numeric variable.

fuel <- contrasts(as.factor(Toy$FuelType))
Toyp1<- sqldf("SELECT Price, Age,KM, CASE WHEN FuelType = 'Diesel' THEN 0 WHEN FuelType = 'Petrol'
              THEN 1 WHEN FuelType = 'CNG' THEN 2 END AS FuelType, HP,MetColor, Automatic, CC,Doors,
              Weight FROM Toy")
summary(Toyp1)
head(Toyp1)


# I get a visual representation of the data with graphs
plot(Price ~ Age, data = Toy)
plot(Price ~ KM, data = Toy)
plot(Price ~ HP, data = Toy)
plot(Price ~ CC, data = Toy)
plot(Price ~ MetColor, data = Toy)
plot(Price ~ Automatic, data = Toy)
plot(Price ~ Weight, data = Toy)
plot(Price ~ FuelType, data = Toy)

#begin the first linear model

first_lm <- lm(Price ~ ., data = Toyp1)
summary(first_lm)

#pull the confidence 

confint(first_lm)

#see the correlation
cor(Toyp1)

#begin the process for mode exhaustive search
x <- Toyp1[,2:10]
y <- Toyp1[,1]
Toyput <- summary(regsubsets(x, y, nbest = 1, nvmax = ncol(x),
                             force.in =NULL, foce.out = NULL, method = "exhaustive"))

Toyreg <- cbind(Toyput$which,Toyput$rsq, Toyput$adjr2, Toyput$cp)

colnames(Toyreg) <- c("(intercept)","Age", "KM", "FuelType", "HP",
                      "MetColor", "Automatic", "CC", "Doors", "Weight", 
                      "R-sq", "R-sq_adj", "Cp")
Toyreg


# the optimal solution is shown below
Toyp2 <- data.frame(Toyp1$Price,Toyp1$Age, Toyp1$KM, Toyp1$FuelType,
                    Toyp1$HP, Toyp1$Automatic, Toyp1$CC,Toyp1$Weight)
colnames(Toyp2) <- c("Price","Age", "KM", "FuelType","HP","Automatic", "CC", "Weight")
Toyp2 <- lm(Price ~ ., data = Toyp2)
summary(Toyp2)

#predictive model
ToyPR <- data.frame(Toyp1$Price,Toyp1$Age,Toyp1$FuelType,Toyp1$HP,
                    Toyp1$MetColor,Toyp1$Automatic,Toyp1$CC,Toyp1$Doors)
colnames(ToyPR) <- c("Price","Age","FuelType","HP","MetColor","Automatic","CC","Doors")

ToyLM <- lm(Price ~., data=ToyPR)
summary(ToyLM)

#now this predicts based on the model

price.pred <- data.frame(Age = 12, FuelType = 1, HP = 185, MetColor = 1, Automatic = 0,  CC = 2000, Doors = 4)
predict(ToyLM,price.pred)
